import openpyxl, json, datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
XLSX=ROOT/"Updated CS Identification all.xlsx"
OUT=ROOT/"data.json"

def clean(v):
    if v is None: return ""
    if isinstance(v,float) and v.is_integer(): return str(int(v))
    return str(v).strip()

wb=openpyxl.load_workbook(XLSX,data_only=True)
ws=wb["Confined Space Location List"]
ignition_headers=[clean(ws.cell(8,c).value) for c in range(19,38) if clean(ws.cell(8,c).value)]

locations=[]
current=""
for r in range(9,ws.max_row+1):
    sec=clean(ws.cell(r,2).value)
    if sec: current=sec
    ident=clean(ws.cell(r,4).value)
    if not ident: continue
    x={
      "sr":clean(ws.cell(r,3).value),"id":ident,"description":clean(ws.cell(r,5).value),
      "area":clean(ws.cell(r,6).value),"location":clean(ws.cell(r,7).value),
      "outdoor":clean(ws.cell(r,8).value),"large":clean(ws.cell(r,9).value),
      "restricted":clean(ws.cell(r,10).value),"occupancy":clean(ws.cell(r,11).value),
      "hazardous":clean(ws.cell(r,12).value),"engulf":clean(ws.cell(r,13).value),
      "converging":clean(ws.cell(r,14).value),"otherHazard":clean(ws.cell(r,15).value),
      "confined":clean(ws.cell(r,16).value),"gha":clean(ws.cell(r,17).value).upper(),
      "zone":clean(ws.cell(r,18).value),"section":current
    }
    x["ignitionStatus"]={h:clean(ws.cell(r,19+i).value) for i,h in enumerate(ignition_headers)}
    x["ignition"]=[h for h,v in x["ignitionStatus"].items() if v.strip() in ("✓","✔","Yes","YES","Y","1","True","TRUE")]
    x["availableSources"]=clean(ws.cell(r,37).value)
    x["sop"]=clean(ws.cell(r,38).value)
    x["hirac"]=clean(ws.cell(r,39).value)
    locations.append(x)

sections={}
for x in locations: sections[x["section"]]=sections.get(x["section"],0)+1
departments=sorted(sections)

entries={}

# Department entry registers come from the dedicated C.S.ENTRY sheets.
# The CRM sheet also contains the PICKLING and ARP records, so those rows
# are split into their actual departments using the identification number.
def entry_department(sheet_dep, ident, area, location):
    u=f"{ident} {area} {location}".upper()
    if u.startswith("PICKLING/") or "PICKLING" in u:
        return "PICKLING"
    if u.startswith("ARP/") or "ARP/CNF/" in u or " ARP " in u:
        return "ARP"
    aliases={"ADMIN":"ADMIN","ADMINISTRATIVE":"ADMIN","CRM":"CRM","CGL":"CGL","CCL":"CCL","UTILITY":"UTILITY","PICKLING":"PICKLING","ARP":"ARP"}
    return aliases.get(sheet_dep.upper().strip(), sheet_dep.upper().strip())

for s in wb.sheetnames[2:]:
    w=wb[s]; header=None
    for r in range(1,15):
        vals=[clean(w.cell(r,c).value).lower() for c in range(1,w.max_column+1)]
        if any("identification no" in v for v in vals): header=r; break
    if not header: continue

    sheet_dep=""
    for c in range(1,w.max_column+1):
        v=clean(w.cell(5,c).value)
        if v and "as on date" not in v.lower() and v.lower() not in ("department","department -"):
            sheet_dep=v.replace("Department -","").strip()
            if sheet_dep: break
    if not sheet_dep: sheet_dep=s.replace(" C.S.ENTRY","").strip()

    for r in range(header+1,w.max_row+1):
        ident=clean(w.cell(r,3).value)
        if not ident: continue
        area=clean(w.cell(r,5).value)
        location=clean(w.cell(r,6).value)
        dep=entry_department(sheet_dep,ident,area,location)
        row={"department":dep,"sr":clean(w.cell(r,2).value),"id":ident,
          "description":clean(w.cell(r,4).value),"area":area,
          "location":location,"outdoor":clean(w.cell(r,7).value),
          "gha":clean(w.cell(r,8).value).upper().replace("NGHA","NGH"),
          "zone":clean(w.cell(r,9).value),"size":clean(w.cell(r,10).value)}
        entries.setdefault(dep,[]).append(row)

# Keep all seven dashboard departments visible in the entry register.
# If a future workbook omits a dedicated sheet, use matching master records
# only as a last-resort fallback; current workbook has real entry data for all.
for dep in departments:
    entries.setdefault(dep,[])

# Stable, useful tab order matching the plant structure.
preferred=["CRM","PICKLING","ARP","CGL","CCL","UTILITY","ADMIN"]
entries={k:entries.get(k,[]) for k in preferred if k in departments or k in entries}
departments=[d for d in preferred if d in departments]

data={"generatedAt":datetime.datetime.now().strftime("%d %b %Y %H:%M"),
      "locations":locations,"sections":sections,"departments":departments,
      "entries":entries,"ignitionHeaders":ignition_headers}
OUT.write_text(json.dumps(data,ensure_ascii=False),encoding="utf-8")
print(f"Generated {OUT} with {len(locations)} locations.")
